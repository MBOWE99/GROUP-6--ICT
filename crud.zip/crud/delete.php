<?php 

$db = mysqli_connect('localhost', 'root', '', 'crudkenny');

	if (isset($_GET['id'])) {
        $delid = $_GET['id'];
        mysqli_query($db, "DELETE FROM crud WHERE id=$delid");
        echo "<p style='font-size: 40px; color: red;'>deleted suscessfuly..</p>";
        header("refresh:2;url=crud.php");
}


 ?>