<?php 
$db = mysqli_connect('localhost', 'root', '', 'crudkenny');

 if(isset($_GET['id'])){
    $getid = $_GET['id'];
    $use = mysqli_query($db,"SELECT * FROM crud WHERE id='$getid'");
    // $patapicha = '';
    while($display = mysqli_fetch_array($use)){
        $fetchid = $display['id'];
        $fetchname = $display['name'];
        $fetchloc = $display['location'];  
        $fetchgend = $display['gender'];  

    }
}
//Updating the detailed
if(isset($_POST['update'])){
   $upname = $_POST['name'];
   $uploc = $_POST['location'];
   $upgend = $_POST['gender'];
    $send  = mysqli_query($db,"UPDATE crud SET name = '$upname', location = '$uploc',gender='$upgend' WHERE id='$getid'");
        if($send >0){
           echo  "<p style='font-size: 40px; color: green;'>updated suscessfuly..</p>";
            header("refresh:2;url=crud.php");
        }
        else{
            echo "failed to update..";
        }
}

 ?>
<!DOCTYPE html>
<html>
<head>
        <title>CRUD</title>
        <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <form method="POST" action="" >
        	<h1>Edit and Update</h1>
                <div class="input-group">
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo $fetchname; ?>">
                </div>
                <div class="input-group">
                        <label>Location</label>
                        <input type="text" name="location" value="<?php echo $fetchloc; ?>">
                </div>                
                <div class="input-group">
                        <label>Gender</label>
                        <input type="text" name="gender" value="<?php echo $fetchgend; ?>">
                </div>
                <div class="input-group">
                        <button class="btn" type="submit" name="update" >Edit and Update</button> <a class="btn" href="crud.php">Back</a>
                </div>
        </form>


</body>
</html>
