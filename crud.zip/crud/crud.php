<?php 
        $db = mysqli_connect('localhost', 'root', '', 'crudkenny');

        if (isset($_POST['save'])) {
                $nam = $_POST['name'];
                $loc = $_POST['location'];
                $ge = $_POST['gender'];
                $res = mysqli_query($db, "INSERT INTO crud VALUES ('','$nam', '$loc','$ge')"); 
               if($res>0){
               	echo "<p style='font-size: 40px; color: green;'>Suscessfuly inserted..</p>";
               }
        }

//Display the result from the database
        $viw='
        	<table >
        		<tr>
        			<th>SNO</th>
        			<th>NAME</th>
        			<th>LOCATION</th>
        			<th>GENDER</th>
                                <th>ACTION</th>
        		</tr>
        ';
        $i=1;
        $show = mysqli_query($db,"SELECT *  FROM crud");
		while($extract = mysqli_fetch_array($show)){
			   $id = $extract['id'];
			   $namee = $extract['name'];
			   $loca = $extract['location'];
			   $gnd = $extract['gender'];
			   $viw.="
			   	<tr >
			   	<td>$i</td>
			   	<td>$namee</td>
			   	<td>$loca</td>
			   	<td>$gnd</td>
			   	<td><a href='edit.php?id=$id'>Edit</a> <a href='delete.php?id=$id'>Delete</a></td>

        			</tr>
			   ";
			   $i++;
			}
        ?>


<!DOCTYPE html>
<html>
<head>
        <title>CRUD</title>
        <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <form method="POST" action="" >
        	<h1>Create, Update, Delete Records</h1>
                <div class="input-group">
                        <label>Name</label>
                        <input type="text" name="name" value="" placeholder="Your name">
                </div>
                <div class="input-group">
                        <label>Location</label>
                        <input type="text" name="location" value="" placeholder="Your location">
                </div>                
                <div class="input-group">
                        <label>Gender</label>
                        <input type="text" name="gender" value="" placeholder="Your gender">
                </div>
                <div class="input-group">
                        <button class="btn" type="submit" name="save" >Save</button>
                </div>
        </form>

        <div style="text-align: center;">
        		<?php echo $viw; ?>
        </div>
</body>
</html>
